sod_pts.shp
Stream baiting stations of Sudden Oak Death (SOD) in the 3-county area in northern California. See Hohl et al. 2014 for an introduction to the topic and a description of the dataset.
Columns:
	-Longitude
	-Latitude
	-Presence_A: Indicates whether SOD has been detected or not
	-POINT_X
	-POINT_Y
	-ELEVATION
Research question: What is the spatial distribution of SOD in northern California?
Tip: Use the binary classification in the Presence_A column to divide the dataset into case and control observations.

Reference:
Hohl, A., Václavík, T., & Meentemeyer, R. K. (2014). Go with the flow: geospatial analytics to quantify hydrologic landscape connectivity for passively dispersed microorganisms. International Journal of Geographical Information Science, 28(8), 1626-1641.


sod_boundary.shp
Boundary of the 3-county area (Sonoma, Mendocino, Humboldt)